import React from 'react';
import LoadBiddingApp from './LoadBiddingApp';

export default function App() {
  return <LoadBiddingApp />;
}
